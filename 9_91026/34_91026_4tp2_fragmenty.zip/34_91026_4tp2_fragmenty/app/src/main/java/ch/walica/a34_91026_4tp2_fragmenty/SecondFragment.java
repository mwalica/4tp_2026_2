package ch.walica.a34_91026_4tp2_fragmenty;

import android.graphics.Color;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.appbar.MaterialToolbar;


public class SecondFragment extends Fragment {

    private MaterialToolbar materialToolbar;
    private RadioGroup radioGroup;
    private TextView tvResult;

    private int selectedRadioId;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_second, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        materialToolbar = view.findViewById(R.id.topAppBar);
        radioGroup = view.findViewById(R.id.radioGroup);
        tvResult = view.findViewById(R.id.tvResult);

        selectedRadioId = radioGroup.getCheckedRadioButtonId();

        if (selectedRadioId == R.id.rbRed) {
            tvResult.setTextColor(Color.RED);
        } else if (selectedRadioId == R.id.rbBlue) {
            tvResult.setTextColor(Color.BLUE);
        }

        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(@NonNull RadioGroup radioGroup, int i) {
                selectedRadioId = i;
                if (selectedRadioId == R.id.rbRed) {
                    tvResult.setTextColor(Color.RED);
                } else if (selectedRadioId == R.id.rbBlue) {
                    tvResult.setTextColor(Color.BLUE);
                }

                RadioButton selectedRb = view.findViewById(selectedRadioId);
                Toast.makeText(requireContext(), "Zaznaczono " + selectedRb.getText(), Toast.LENGTH_SHORT).show();
            }
        });


        materialToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                requireActivity().getSupportFragmentManager().beginTransaction().replace(R.id.fragmentContainerView, new FirstFragment()).commit();
            }
        });

        if (getArguments() != null) {
            String name = getArguments().getString("name_key");
            tvResult.setText(name);
        }
    }
}
package ch.walica.a4_temp40926_4tp2_activity_intent;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class SecondActivity extends AppCompatActivity {

    private TextView tvResult;
    private Button btnBack;
    private String eneteredText = "";
    private int age;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_second);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        btnBack = findViewById(R.id.btnBack);
        tvResult = findViewById(R.id.tvResult);

        if(getIntent().hasExtra("key_text") && getIntent().hasExtra("key_number")) {
            eneteredText = getIntent().getStringExtra("key_text");
            age = getIntent().getIntExtra("key_number", 0);
            tvResult.setText(eneteredText + " " + age);
        }

        btnBack.setOnClickListener(view -> {
            finish();
        });
    }
}
package ch.walica.a14_temp180926_4tp2_snackbar;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.snackbar.Snackbar;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        View myView = findViewById(R.id.myView);
        Button btnShow = findViewById(R.id.btnShow);

        btnShow.setOnClickListener(view -> {
            Snackbar.make(btnShow, "Czy chcesz zmienić kolor?", Snackbar.LENGTH_INDEFINITE)
                    .setTextColor(Color.CYAN)
                    .setBackgroundTint(Color.rgb(30, 55, 200))
                    .setAnimationMode(Snackbar.ANIMATION_MODE_SLIDE)
                    .setAction("Tak", v -> {
                        myView.setBackgroundColor(Color.RED);
                    })
                    .setActionTextColor(Color.GREEN)
                    .setAnchorView(myView)
                    .show();
        });
    }
}
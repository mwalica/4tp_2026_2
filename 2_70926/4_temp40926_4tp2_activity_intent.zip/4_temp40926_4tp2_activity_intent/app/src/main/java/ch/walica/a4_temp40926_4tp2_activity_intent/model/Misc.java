package ch.walica.a4_temp40926_4tp2_activity_intent.model;

import java.io.Serializable;
import java.util.Random;

public class Misc implements Serializable {
    private String text;
    private int number;

    public Misc(String text) {
        this.text = text;
        this.number = new Random().nextInt(81) + 18;
    }

    public String getText() {
        return text;
    }

    public int getNumber() {
        return number;
    }
}

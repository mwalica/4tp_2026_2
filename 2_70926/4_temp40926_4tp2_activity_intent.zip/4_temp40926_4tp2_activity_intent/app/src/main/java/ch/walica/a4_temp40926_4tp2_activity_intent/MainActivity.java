package ch.walica.a4_temp40926_4tp2_activity_intent;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Random;

import ch.walica.a4_temp40926_4tp2_activity_intent.model.Misc;

public class MainActivity extends AppCompatActivity {

    private EditText etEnteredText;
    private Button btnSend;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        etEnteredText = findViewById(R.id.etEnteredText);
        btnSend = findViewById(R.id.btnSend);

        btnSend.setOnClickListener(view -> {
            String enteredText = etEnteredText.getText().toString();
            if(!enteredText.isEmpty()) {
                Misc obj = new Misc(enteredText);
                Intent intent = new Intent(MainActivity.this, SecondActivity.class);
//                intent.putExtra("key_text", enteredText);
//                intent.putExtra("key_number", new Random().nextInt(1000));
                intent.putExtra("key_object", obj);
                startActivity(intent);
            }

        });
    }
}
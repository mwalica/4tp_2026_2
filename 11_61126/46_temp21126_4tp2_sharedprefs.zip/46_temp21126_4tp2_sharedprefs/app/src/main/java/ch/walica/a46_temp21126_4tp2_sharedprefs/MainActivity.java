package ch.walica.a46_temp21126_4tp2_sharedprefs;

import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private EditText etEnteredText;
    private TextView tvEnteredText, tvResult;
    private Button btnSave, btnClear;
    private SwitchCompat mySwitch;
    private LinearLayout main;

    private String enteredText = "";
    private boolean switchState = false;

    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        etEnteredText = findViewById(R.id.etEnteredText);
        tvEnteredText = findViewById(R.id.tvEnteredText);
        tvResult = findViewById(R.id.tvResult);
        btnSave = findViewById(R.id.btnSave);
        btnClear = findViewById(R.id.btnClear);
        mySwitch = findViewById(R.id.mySwitch);
        main = findViewById(R.id.main);

        sharedPreferences = getSharedPreferences("shared_prefs_1", MODE_PRIVATE);

        enteredText = sharedPreferences.getString("text_key", "");
        switchState = sharedPreferences.getBoolean("color_key", false);

        screenSettings();

        etEnteredText.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(Editable editable) {

            }

            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                enteredText = charSequence.toString();
                tvEnteredText.setText(enteredText);
            }
        });

        btnSave.setOnClickListener(view -> {
            tvResult.setText(enteredText);
            sharedPreferences.edit().putString("text_key", enteredText).apply();
            Toast.makeText(this, "tekst zapisany", Toast.LENGTH_SHORT).show();
        });

        mySwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(@NonNull CompoundButton compoundButton, boolean b) {
                switchState = b;
                sharedPreferences.edit().putBoolean("color_key", switchState).apply();
               screenSettings();
            }
        });

        btnClear.setOnClickListener(view -> {
            sharedPreferences.edit().clear().apply();
            enteredText = "";
            switchState = false;
            screenSettings();
        });
    }

    private void screenSettings() {
        tvResult.setText(enteredText);
        mySwitch.setChecked(switchState);
        if(switchState) {
            main.setBackgroundColor(Color.GRAY);
        } else {
            main.setBackgroundColor(Color.WHITE);
        }
    }
}
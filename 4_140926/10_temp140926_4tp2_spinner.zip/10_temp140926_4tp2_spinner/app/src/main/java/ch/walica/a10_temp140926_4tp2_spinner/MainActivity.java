package ch.walica.a10_temp140926_4tp2_spinner;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private Spinner spinner;
    private TextView tvResult;
    private Button btnShow;
    private View myView;

    private String selectedColor = "";
    private String[] colors = {"red", "green", "blue", "yellow", "grey"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        spinner = findViewById(R.id.spinner);
        tvResult = findViewById(R.id.tvResult);
        btnShow = findViewById(R.id.btnShow);
        myView = findViewById(R.id.myView);

//        selectedColor = spinner.getSelectedItem().toString();
//        tvResult.setText(selectedColor);

        //tworzymy adapter
        ArrayAdapter<String> adapter = new ArrayAdapter<>(MainActivity.this, android.R.layout.simple_spinner_dropdown_item, colors);
        spinner.setAdapter(adapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                Log.d("my_log", "onItemSelected: " + adapterView.getSelectedItem().toString());
                selectedColor = adapterView.getSelectedItem().toString();
                String colorPL = switch(selectedColor) {
                    case "red" -> "Czerwony";
                    case "green" -> "Zielony";
                    case "blue" -> "Niebieski";
                    case "yellow" -> "Żółty";
                    case "grey" -> "Szary";
                    default -> "Brak koloru";
                };

                tvResult.setText(colorPL);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        btnShow.setOnClickListener(view -> {
            //int selected = Color.parseColor(colors[spinner.getSelectedItemPosition()]);
            int selected = Color.parseColor(spinner.getSelectedItem().toString());
            myView.setBackgroundColor(selected);
        });

    }
}
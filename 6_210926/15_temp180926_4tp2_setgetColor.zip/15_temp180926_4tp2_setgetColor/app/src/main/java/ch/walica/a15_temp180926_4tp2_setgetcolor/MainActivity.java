package ch.walica.a15_temp180926_4tp2_setgetcolor;

import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private Button btnCopy;
    private Button view1, view2;
    private Random random = new Random();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        btnCopy = findViewById(R.id.btnCopy);
        view1 = findViewById(R.id.view1);
        view2 = findViewById(R.id.view2);

        //view1.setBackgroundColor(Color.rgb(random.nextInt(256), random.nextInt(256), random.nextInt(256)));
        view1.setBackgroundTintList(ColorStateList.valueOf(Color.rgb(random.nextInt(256), random.nextInt(256), random.nextInt(256))));

        btnCopy.setOnClickListener(view -> {
            //ColorDrawable background = (ColorDrawable) view1.getBackground();
            //int bgColor = background.getColor();
            //view2.setBackground(background);
            //view2.setBackgroundColor(bgColor);

            int bgColor = view1.getBackgroundTintList().getColorForState(new int[]{android.R.attr.state_enabled}, 0);
            view2.setBackgroundTintList(ColorStateList.valueOf(bgColor));
        });
    }
}